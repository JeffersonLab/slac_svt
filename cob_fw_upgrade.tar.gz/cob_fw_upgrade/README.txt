Extract ipmitool tarball, configure, then build
Add ipmitool executables to path

Source SDK V0.11.1 i86-linux-64 envs-sdk.sh

Get board version dump:
ipmitool -I lan -H <shelf_manager_ip> -t <cob_ipmb_addr> -b 0 -A NONE fru print 0

Example:
ipmitool -I lan -H egbert-sm -t 0x82 -b 0 -A NONE fru print 0

rdsrv101:smaldona> ipmitool -I lan -H egbert-sm -t 0x82 -b 0 -A NONE fru print 0
 Board Mfg Date        : Tue May 27 16:00:00 2014
 Board Mfg             : SLAC
 Board Product         : Cluster On Board
 Board Serial          : e200000019b80570
 Board Part Number     : PC_248_101_01_C08
 Product Manufacturer  : SLAC
 Product Name          : Cluster On Board
 Product Part Number   : PC_248_101_01_C08
 Product Version       : 0
 Product Serial        : e200000019b80570
 Product Asset Tag     : COB8-37

Get COB board version:
The board version is last digits in Board and Product Part Number output _CXX.

Example:
Board Version for PC_248_101_01_C08 is 8

Select firmware upgrade file for COB version.
ipmc_cob_v[board_version]_V1-4-0_fw.img 

Example
ipmc_cob_v8_V1-4-0_fw.img

Start upgrade:
ipmi_cmd <shelf_manager_ip> hpm upgrade <upgrade_file> all activate
Enter "Y" for "Contine ignoring ID" prompt.

Example:
[semaldon@pddaq-gen02 ~]$ ipmi_cmd 192.168.1.2 1 hpm upgrade ipmc_cob_v8_V1-4-0_fw.img all activate

PICMG HPM.1 Upgrade Agent 1.0.9:

Validating firmware image integrity...OK
Performing preparation stage...
   Invalid device ID 12

   Image Information
       Device Id : 0x1
       Prod   Id : 0xac0b
       Manuf  Id : 0x009d50
   Board Information
       Device Id : 0x12
       Prod   Id : 0xbaca
       Manuf  Id : 0x00400a
Continue ignoring DeviceID/ProductID/ManufacturingID (Y/N) :Y

Services may be affected during upgrade. Do you wish to continue? y/n y
OK

Performing upgrade stage:

-------------------------------------------------------------------------------
|ID | Name       |                     Versions                        |  %   |
|   |            |      Active     |      Backup     |      File       |      |
|---|------------|-----------------|-----------------|-----------------|------|
|*0 |A2F-ATCA F/W|   1.35 53B584DB |   1.35 53B4670B |   1.40 551E11B8 |100 % |
|   | Upload Time: 02.13           | Image Size: 1f6cf                        |
-------------------------------------------------------------------------------
(*) Component requires Payload Cold Reset
Performing activation stage:

Firmware upgrade procedure successful


Notes:

First time, upgrade may fail with error
