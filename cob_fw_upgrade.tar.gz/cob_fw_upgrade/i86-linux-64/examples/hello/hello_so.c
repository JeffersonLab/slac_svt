
#include "debug/print.h" // include the SDK debug library

/*
** ++
**
**
** --
*/

int hello(void)
  {
  dbg_printv("Hello from the so world!\n");
  return 0;
  }

int goodbye(void)
  {
  dbg_printv("Goodbye from the so world!\n");
  return 0;
  }
