
#include <stdio.h>

extern int hello(void);   // the hello function in hello.so
extern int goodbye(void); // the goodbye function in hello.so

/*
** ++
**
**
** --
*/

int main(int argc, const char** argv)
  {
  printf("Hello from the exe world!\n");
  
  /* execute the hello function from hello.so */
  hello();
  
  /* execute the goodbye function from hello.so */
  goodbye();
  
  printf("Goodbye from the exe world!\n");
  return 0;
  }
