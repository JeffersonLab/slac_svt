#!/bin/bash
#
# usage:  build.sh <architecture>
#
# Build the hello host executables
#

if [ $# -lt 1 ]; then
  echo "$BASH_SOURCE requires the architecture as an argument (e.g. i86-linux-32)"
  exit -1
fi
arch=$1; shift

# bash trickery to get the full path to the parent directory
sdkroot=$(dirname ${BASH_SOURCE})
sdkroot=$(cd ${sdkroot}/../.. > /dev/null 2>&1 && pwd)
. ${sdkroot}/tools/envs-sdk.sh

# 32 bit i86 linux requires -m32 C++ option
build_arg=
case ${arch} in 
  *-32) 
    build_arg="-m32"   ;;
  *-rceCA9)
    ;;
esac

linux-gcc ${build_arg} hello_so.c -c -fpic -I${sdkroot}/include/core -o hello_so.o

#Link a shared library
linux-g++ ${build_arg} hello_so.o -shared -L${sdkroot}/lib -o libhello.so

#Compile an executable object
linux-gcc ${build_arg} hello.c -c -fpic -I${sdkroot}/include/core -o hello.o

#Link the executable image
linux-g++ ${build_arg} hello.o ${sdkroot}/lib/libdebug.so libhello.so -Wl,-rpath='$ORIGIN/../../examples/hello:$ORIGIN/../../lib' -o hello

