// -*-Mode: C++;-*-
/*!
*
* @brief   Intel-64-only functions for handling times
*
* Currently this interface is empty.

* @author  Anonymous -- REG/DRD - (someone@slac.stanford.edu)
*
* @date    May 27 2014 -- Created
*
* $Revision: 3326 $
*
* @verbatim
*                               Copyright 2014
*                                     by
*                        The Board of Trustees of the
*                      Leland Stanford Junior University.
*                             All rights reserved.
* @endverbatim
*/
#ifndef TOOL_TIME_TIME_IMPL_HH
#define TOOL_TIME_TIME_IMPL_HH


#endif // TOOL_TIME_TIME_IMPL_HH
