// -*-Mode: C++;-*-
/**
@file
@brief CPU parameters.
@verbatim
                               Copyright 2013
                                    by
                       The Board of Trustees of the
                    Leland Stanford Junior University.
                           All rights reserved.
@endverbatim

@par Facility:
DAT

@author
Stephen Tether <tether@slac.stanford.edu>

@par Date created:
2013/08/15

@par Last commit:
\$Date: 2014-06-04 17:27:22 -0700 (Wed, 04 Jun 2014) $ by \$Author: panetta $.

@par Revision number:
\$Revision: 3344 $

@par Credits:
SLAC
*/
#if !defined(CONFIGURATION_SYSTEM_CPU_HH)
#define      CONFIGURATION_SYSTEM_CPU_HH



namespace configuration {

  namespace system {
  }

}
#endif
