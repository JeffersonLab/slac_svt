#!/bin/bash
#
# Usage install-sdk.sh  [development]
#
# Install a copy of the Linux SDK for i86-linux-64
#
# * Fetches the includes and libraries from their respective 
#   repositories if [development] is not set
#
# * Compiles the host tools


sdkroot=$(dirname ${BASH_SOURCE})
sdkroot=$(cd ${sdkroot}/.. > /dev/null 2>&1 && pwd)

# Build the host tools
echo -n "Building the host tools..."
cd ${sdkroot}/tools
${sdkroot}/tools/atca/build.sh i86-linux-64
echo "done"

cd - > /dev/null
echo "done installing SDK"
