import os,re,sys

DEFAULT_ENV_FILE = "uboot_env.txt"

env = []

args = sys.argv

def usage():
  print "Usage: mkubootenv <outfile> <mac> <phy> <boot_mode> [usrvar=usrval]"
  print " i.e.: mkubootenv uboot.env 00:01:02:03:04:05 0x1 sdboot_rtems"
  print " i.e.: mkubootenv uboot.env 00:01:02:03:04:05 0x1 sdboot_linux 00:00:00:00:00:00"
  sys.exit(1)


if len(args) < 5:
  usage()

envfile = sys.argv[1]
tmpfile = "/tmp/"+str(os.getpid())+".ubt"
outfd = open(tmpfile,'w')
outfd.write("ethaddr="+sys.argv[2]+"\n")
outfd.write("phycfg="+sys.argv[3]+"\n")
outfd.write("modeboot="+sys.argv[4]+"\n")

#allow for a generic user environment variables
if len(args) >= 6:
  #validate format of user arg
  if len(sys.argv[5].split("=")) != 2:
    print "Invalid user argument",sys.argv[5]
    usage()
  print "Set user arg",sys.argv[5]
  outfd.write(sys.argv[5]+"\n")

outfd.write("bootdelay=3\n")

fd = open(DEFAULT_ENV_FILE)
while 1:
  ln = fd.readline()
  if ln == "":
    break
  outfd.write(ln)

fd.close()
outfd.close()

ret = os.system("mkenvimage -s 131072 -o "+envfile+" "+tmpfile)
os.system("rm "+tmpfile)
if ret == 0:
  print "Created uboot env file "+envfile
