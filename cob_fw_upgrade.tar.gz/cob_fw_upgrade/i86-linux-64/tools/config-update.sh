#!/bin/sh
#
# Usage:  config-update.sh <sdk_tarball>
#
# Configures the filesystem and nfs server for the uploaded SDK tarball
# 

sdk_tarball=$1

mkdir -p /srv/nfs4/dsl

#generate IP network for NFS server DSL dir
ipAddr=`hostname -i`

oct1=$(echo ${ipAddr} | tr "." " " | awk '{ print $1}')
oct2=$(echo ${ipAddr} | tr "." " " | awk '{ print $2}')
oct3=$(echo ${ipAddr} | tr "." " " | awk '{ print $3}')
oct4=$(echo ${ipAddr} | tr "." " " | awk '{ print $4}')

ipNet="/srv/nfs4 $oct1.$oct2.$oct3.0/24(rw,fsid=0,no_subtree_check,nohide)"
rm -f /etc/exports
echo "$ipNet" > /etc/exports
ipNet="/srv/nfs4/dsl $oct1.$oct2.$oct3.0/24(rw,no_subtree_check,nohide)"
echo "$ipNet" >> /etc/exports

systemctl stop rpcbind
systemctl stop nfs-server
umount /srv/nfs4/dsl
systemctl start rpcbind
systemctl start nfs-server
rm -rf /var/local/RCE_SDK
tar --no-same-owner --touch -xf ${sdk_tarball}
mount --bind /var/local/RCE_SDK /srv/nfs4/dsl
rm $sdk_tarball
rm /var/local/config-update.sh
sync
