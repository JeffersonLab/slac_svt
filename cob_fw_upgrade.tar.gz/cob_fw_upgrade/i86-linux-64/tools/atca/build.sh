#!/bin/bash
#
# usage:  build.sh <architecture>
#
# Build the atca host executables for various linuxes
#

if [ $# -lt 1 ]; then
  echo "$BASH_SOURCE requires the architecture as an argument (e.g. i86-linux-32)"
  exit -1
fi
arch=$1; shift

# bash trickery to get the full path to the parent directory
sdkroot=$(dirname ${BASH_SOURCE})
sdkroot=$(cd ${sdkroot}/../.. > /dev/null 2>&1 && pwd)
. ${sdkroot}/tools/envs-sdk.sh

# 32 bit i86 linux requires -m32 C++ option
build_arg=
case ${arch} in 
  *-32) 
    build_arg="-m32"   ;;
  *-rceCA9)
    ;;
esac


#Compile the atca objects
linux-g++ ${build_arg} ${sdkroot}/tools/atca/atca_dump.cc -c -fpic -I${sdkroot}/include/core -o ${sdkroot}/tools/atca/atca_dump.o
linux-g++ ${build_arg} ${sdkroot}/tools/atca/atca_mac.cc  -c -fpic -I${sdkroot}/include/core -o ${sdkroot}/tools/atca/atca_mac.o
linux-g++ ${build_arg} ${sdkroot}/tools/atca/atca_ip.cc   -c -fpic -I${sdkroot}/include/core -o ${sdkroot}/tools/atca/atca_ip.o

#Link the executable images
linux-g++ ${build_arg} ${sdkroot}/tools/atca/atca_dump.o -L${sdkroot}/lib -lc -ldl -lrt -latca_l -lstring -lio -lexception -lhash -llogger -lconcurrency -lmemory -lkvt -lcsi -ldebug -ldsl_l -ludp -lnet -Wl,-rpath='$ORIGIN/../lib' -o ${sdkroot}/bin/atca_dump
linux-g++ ${build_arg} ${sdkroot}/tools/atca/atca_mac.o  -L${sdkroot}/lib -lc -ldl -lrt -latca_l -lstring -lio -lexception -lhash -llogger -lconcurrency -lmemory -lkvt -lcsi -ldebug -ldsl_l -ludp -lnet -Wl,-rpath='$ORIGIN/../lib' -o ${sdkroot}/bin/atca_mac
linux-g++ ${build_arg} ${sdkroot}/tools/atca/atca_ip.o   -L${sdkroot}/lib -lc -ldl -lrt -latca_l -lstring -lio -lexception -lhash -llogger -lconcurrency -lmemory -lkvt -lcsi -ldebug -ldsl_l -ludp -lnet -Wl,-rpath='$ORIGIN/../lib' -o ${sdkroot}/bin/atca_ip

rm ${sdkroot}/tools/atca/atca_dump.o
rm ${sdkroot}/tools/atca/atca_mac.o
rm ${sdkroot}/tools/atca/atca_ip.o

